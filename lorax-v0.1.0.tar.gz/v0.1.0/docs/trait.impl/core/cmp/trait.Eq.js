(function() {
    var implementors = Object.fromEntries([["lorax",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"enum\" href=\"lorax/config/enum.ModelSize.html\" title=\"enum lorax::config::ModelSize\">ModelSize</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"enum\" href=\"lorax/lora/config/enum.BiasType.html\" title=\"enum lorax::lora::config::BiasType\">BiasType</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"enum\" href=\"lorax/lora/config/enum.TaskType.html\" title=\"enum lorax::lora::config::TaskType\">TaskType</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/cmp/trait.Eq.html\" title=\"trait core::cmp::Eq\">Eq</a> for <a class=\"enum\" href=\"lorax/models/enum.ModelType.html\" title=\"enum lorax::models::ModelType\">ModelType</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[1019]}