(function() {
    var implementors = Object.fromEntries([["lorax",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/error/trait.Error.html\" title=\"trait core::error::Error\">Error</a> for <a class=\"enum\" href=\"lorax/error/enum.Error.html\" title=\"enum lorax::error::Error\">Error</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/error/trait.Error.html\" title=\"trait core::error::Error\">Error</a> for <a class=\"enum\" href=\"lorax/training/data/enum.DataError.html\" title=\"enum lorax::training::data::DataError\">DataError</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[534]}