(function() {
    var implementors = Object.fromEntries([["lorax",[["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/fmt/trait.Display.html\" title=\"trait core::fmt::Display\">Display</a> for <a class=\"enum\" href=\"lorax/error/enum.Error.html\" title=\"enum lorax::error::Error\">Error</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/fmt/trait.Display.html\" title=\"trait core::fmt::Display\">Display</a> for <a class=\"enum\" href=\"lorax/models/enum.ModelType.html\" title=\"enum lorax::models::ModelType\">ModelType</a>"],["impl <a class=\"trait\" href=\"https://doc.rust-lang.org/1.87.0/core/fmt/trait.Display.html\" title=\"trait core::fmt::Display\">Display</a> for <a class=\"enum\" href=\"lorax/training/data/enum.DataError.html\" title=\"enum lorax::training::data::DataError\">DataError</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[801]}