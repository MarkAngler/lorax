(function() {
    var implementors = Object.fromEntries([["lorax",[["impl Stream for <a class=\"struct\" href=\"lorax/training/data/loaders/struct.DataLoaderStream.html\" title=\"struct lorax::training::data::loaders::DataLoaderStream\">DataLoaderStream</a>"]]]]);
    if (window.register_implementors) {
        window.register_implementors(implementors);
    } else {
        window.pending_implementors = implementors;
    }
})()
//{"start":57,"fragment_lengths":[204]}